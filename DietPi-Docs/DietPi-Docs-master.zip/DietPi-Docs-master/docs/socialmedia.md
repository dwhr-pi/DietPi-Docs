---
title: DietPi Social Media Channels
description: The social media channels maintained by the DietPi project team where you can contact us and get new about DietPi
---

# Social media

## DietPi on Twitter

DietPi announcements are done via Twitter: <https://twitter.com/DietPi_>

## DietPi on Facebook

DietPi announcements and discussions are done via Facebook: <https://www.facebook.com/groups/167403007229675>

## DietPi Blog page

We created a blog page about DietPi features and hints: <https://dietpi.com/blog/>
