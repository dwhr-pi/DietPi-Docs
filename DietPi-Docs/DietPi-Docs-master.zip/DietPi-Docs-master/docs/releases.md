---
title: DietPi Release Notes
description: Overview of DietPi releases with applied new software and features, hardware support, optimisations and bug fixes
---

# DietPi Releases

- [v8.12 December 2022](v8_12/)
- [v8.11 November 2022](v8_11/)
- [v8.10 October 2022](v8_10/)
- [v8.9 September 2022](v8_9/)
- [v8.8 August 2022](v8_8/)
- [v8.7 July 2022, vol 2](v8_7/)
- [v8.6 July 2022](v8_6/)
- [v8.5 May 2022](v8_5/)
- [v8.4 April 2022, vol 2](v8_4/)
- [v8.3 April 2022](v8_3/)
- [v8.2 March 2022](v8_2/)
- [v8.1 February 2022](v8_1/)
- [v8.0 January 2022](v8_0/)
- [v7.9 December 2021](v7_9/)
- [v7.8 November 2021](v7_8/)
- [v7.7 October 2021](v7_7/)
- [v7.6 September 2021](v7_6/)
- [v7.5 August 2021](v7_5/)
- [v7.4 July 2021](v7_4/)
- [v7.3 June 2021](v7_3/)
- [v7.2 May 2021](v7_2/)
- [v7.1 April 2021](v7_1/)
- [v7.0 February 2021](v7_0/)
- [v6.34 December 2020](v6_34/)
- [v6.33 October 2020](v6_33/)
- [v6.32 August 2020](v6_32/)
- [v6.31 July 2020](v6_31/)
- [v6.30 May 2020](v6_30/)
- [v6.29 May 2020](v6_29/)
- [v6.28 January 2020](v6_28/)
- [v6.27 January 2020](v6_27/)

For earlier updates check the **[Forum Archive](https://dietpi.com/phpbb/viewforum.php?f=10)**.
